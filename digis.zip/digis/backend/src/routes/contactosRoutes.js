// src/routes/contactosRoutes.js
const express = require('express');
const router = express.Router();
const contactosController = require('../controllers/contactosController');
const auth = require('../middlewares/auth');
// CRUD Endpoints
router.post('/', contactosController.crearContacto);            // Crear
router.get('/', contactosController.obtenerContactos);           // Obtener todos
router.get('/search',  contactosController.obtenerPorNombre); // Obtener por Nombre
router.get('/:DNI', contactosController.obtenerContactoPorDNI);  // Obtener por DNI
router.put('/:DNI', contactosController.actualizarContacto);     // Actualizar
router.delete('/:DNI',  contactosController.eliminarContacto);    // Eliminar
router.delete('/bulk-delete',  contactosController.eliminarContactos);

module.exports = router;
